#include "../Header/udp_ServerProperty.h"
#include "../Header/udp_server.h"

int main(){
    UDP_Server * udp_server=new UDP_Server;
    udp_server->Driver();
    return 0;
}