#ifndef UDP_EXCEPTION_H_
#define UDP_EXCEPTION_H_
#include<string>
#include<stdexcept>
class Exception{
    private:
        std::string m_s;
    public:
        Exception(std::string s) : m_s(s) {};
        ~Exception(){};
        std::string description() {return m_s;}
};


#endif