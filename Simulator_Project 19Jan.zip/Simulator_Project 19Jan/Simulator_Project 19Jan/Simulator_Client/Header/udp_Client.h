#ifndef _UDP_CLIENT_H_
#define _UDP_CLIENT_H_
#include "udp_ClientProperty.h"
#include "udp_Exception.h"

class udp_ClientUnicast:public udp_ClientProperty{
    public:
        void signal_Handler(int signal);
        int createSocket();
        void sendReceiveData(int* udpClientSocket);
        void udpClientUnicast();
        udp_ClientUnicast();
        ~udp_ClientUnicast();
};
class udp_ClientMulticast:public udp_ClientProperty{
    public:
        void udpClientMulticast();
        udp_ClientMulticast();
        ~udp_ClientMulticast();
};
class udp_ClientBroadCast:public udp_ClientProperty{
    public:
        void udpClientBroadCast();
        udp_ClientBroadCast();
        ~udp_ClientBroadCast();
};

class UDP_Client{
    public:
        void selectOperation();
        void Driver();
};



void selectOperation();
void Driver();

#endif